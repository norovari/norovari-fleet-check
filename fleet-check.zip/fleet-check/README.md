# Norovari Fleet Risk Check

A short, mobile-first Q&A tool for fleet operators and financial managers at
prospective pilot fleets — built as a lead-generation and qualification tool,
separate from the investor terminal. Meant to be shared casually (WhatsApp,
SMS) and completed in about two minutes.

This is a plain static HTML page plus one Vercel serverless function — no
build step, no framework, no dependencies to install.

## What it does

1. Visitor picks a track: **Fleet Operations** or **Financial Oversight**.
2. Answers a short set of plain-language questions (6 for Fleet Operations,
   4 for Financial Oversight). None of the questions or answers touch
   Sentinel's technical architecture — everything here is about the
   visitor's own fleet, costs, and decision authority. That's deliberate:
   nothing here should ever need to be gated the way the investor console's
   Tier 3/4 content is.
3. Sees a short, tailored result line based on their answers.
4. Can leave their name, company, and a contact number/email to be
   considered for the pilot cohort ("submitted for review" — never an
   instant, unconditional grant).
5. Gets a personal share link (`?ref=<code>`) to pass to a peer. If that
   peer completes the flow, their submission carries the referring code,
   so referrals are attributable without needing accounts or logins.

## File structure

```
index.html       — the entire front end (markup, styles, and JS in one file)
api/submit.js    — serverless function that receives completed submissions
```

## Before you deploy: two placeholders need real values

Open `index.html` and search for these two constants near the top of the
`<script>` block:

```js
const REWARD_TEXT = "[[REWARD — TBD, e.g. 'priority placement in our first pilot cohort']]";
const REFERRAL_REWARD_TEXT = "[[REFERRAL REWARD — TBD, e.g. 'an extra month of SaaS on your own pilot']]";
```

Replace both with the actual offer text before sharing the link with anyone
— they're visible on the result screen exactly as written, so leaving the
brackets in would mean sending fleet managers a page that literally says
"TBD."

## Deploying (new, separate Vercel project)

This repo is meant to be its own Vercel project, independent of the investor
terminal — a different codebase, different environment variables, different
URL.

1. Push this repo to GitHub.
2. In Vercel, **Add New Project** and import this repo. Vercel will detect
   `index.html` at the root and `api/submit.js` as a serverless function
   automatically — no framework preset, no build command needed.
3. In the project's **Settings → Environment Variables**, add:
   - `SHEET_WEBHOOK_URL` — the Google Apps Script webhook URL to send
     completed leads to. This can point at the same sheet the investor
     terminal uses (leads land tagged `Fleet Check Lead` in the tier
     column, so they're easy to filter from qualified investor leads) or a
     dedicated sheet — your choice, just point this at whichever one you
     want.
   - `ALLOWED_ORIGIN` (optional) — restricts which domains can call
     `/api/submit`. Defaults to `*` (any origin) if not set.
4. Deploy. You'll get a free `<project-name>.vercel.app` URL.

## How referrals are tracked

There's no login or account system — it's a single code embedded in the
URL. When someone finishes the flow, they get a "copy your share link"
button that appends `?ref=<their code>` to the page URL. If a new visitor
arrives via that link and completes the flow themselves, their submission
includes `referredBy: <that code>`, so you can match the two rows in your
sheet manually. Each submission also generates and logs its own
`ownRefCode`, so a chain of referrals stays traceable.

## Editing the questions or copy

Everything content-related lives in the `TRACKS` object near the top of the
`<script>` block in `index.html` — each track has its own `intro`,
`questions` array, and a `resultLine()` function that picks the tailored
summary based on answers. No other part of the file needs to change to
edit wording, add/remove a question, or adjust the result logic.

## What gets sent to your sheet per submission

- `tier`: always `"Fleet Check Lead"` (distinguishes these from investor
  console leads if sharing a sheet)
- `org`: company name
- `email`: whatever contact info they gave (phone or email)
- `source`: submitter's IP
- `timestamp`: ISO timestamp
- `answers`: a JSON blob containing the track, name, the raw list of
  answer values, their own referral code, and the referral code they came
  in on (if any)

No technical detail, no architecture, no IP — only the plain-language
answers the visitor themselves chose from a multiple-choice list.
